/**
    The CropType class is an enumeration of the crop types.
 */
public enum CropType {
    ROOT_CROP,
    FLOWER,
    FRUIT_TREE
}
