/**
 The FarmerType class is an enumeration of the registration statuses of the farmer.
 */
public enum FarmerType {
    FARMER,
    REGISTERED_FARMER,
    DISTINGUISHED_FARMER,
    LEGENDARY_FARMER
}